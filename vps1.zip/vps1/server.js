const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const { spawn } = require('child_process');
const path = require('path');
const fs = require('fs');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

const sessions = new Map();
const BASE_DIR = '/data/data/com.termux/files/home/terminal_servers';

if (!fs.existsSync(BASE_DIR)) {
    fs.mkdirSync(BASE_DIR, { recursive: true });
    console.log(`✅ বেস ডিরেক্টরি: ${BASE_DIR}`);
}

function ensureServerDir(serverId, serverName) {
    const safeName = serverName.replace(/[^a-zA-Z0-9_-]/g, '_');
    const serverDir = path.join(BASE_DIR, `${serverId}_${safeName}`);
    if (!fs.existsSync(serverDir)) {
        fs.mkdirSync(serverDir, { recursive: true });
    }
    return serverDir;
}

function getFileList(dir) {
    try {
        return fs.readdirSync(dir).filter(f => !f.startsWith('.')).map(f => {
            const stat = fs.statSync(path.join(dir, f));
            return { name: f, size: stat.size, isDir: stat.isDirectory() };
        });
    } catch(e) { return []; }
}

function broadcastToSession(session, type, data) {
    if (!session.wsClients) return;
    session.wsClients.forEach(client => {
        if (client && client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify({ type, data }));
        }
    });
}

wss.on('connection', (ws, req) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const termId = url.searchParams.get('terminalId');
    const username = url.searchParams.get('username') || 'user';
    const serverName = url.searchParams.get('serverName') || 'server';

    if (!termId) {
        ws.close();
        return;
    }

    const serverDir = ensureServerDir(termId, serverName);
    let session = sessions.get(termId);

    if (session && session.process) {
        session.wsClients = session.wsClients || [];
        session.wsClients.push(ws);
        
        ws.send(JSON.stringify({ type: 'monitor', data: `🟢 পুনরায় সংযুক্ত` }));
        ws.send(JSON.stringify({ type: 'file_list', data: getFileList(serverDir), cwd: serverDir }));
        
        const messageHandler = (msg) => handleMessage(msg, session, ws);
        ws.on('message', messageHandler);
        ws.on('close', () => {
            session.wsClients = session.wsClients.filter(c => c !== ws);
        });
        return;
    }
    
    const shell = spawn('sh', [], {
        cwd: serverDir,
        env: { 
            ...process.env, 
            PS1: `${username}@${serverName}:~$ `, 
            TERM: 'xterm-256color',
            HOME: BASE_DIR
        }
    });

    session = { 
        process: shell, 
        username, 
        serverName,
        cwd: serverDir,
        termId,
        wsClients: [ws]
    };
    
    sessions.set(termId, session);
    
    shell.stdout.on('data', (data) => {
        broadcastToSession(session, 'output', data.toString());
    });
    
    shell.stderr.on('data', (data) => {
        broadcastToSession(session, 'error', data.toString());
    });
    
    shell.on('close', (code) => {
        broadcastToSession(session, 'monitor', `🔴 প্রসেস বন্ধ (code ${code})`);
        sessions.delete(termId);
    });
    
    function handleMessage(message, sess, clientWs) {
        let msgStr = message;
        if (typeof message !== 'string') {
            try {
                msgStr = message.toString();
            } catch(e) {
                return;
            }
        }
        
        try {
            const parsed = JSON.parse(msgStr);
            
            if (parsed.type === 'command') {
                if (sess.process && sess.process.stdin) {
                    sess.process.stdin.write(parsed.command + '\n');
                    broadcastToSession(sess, 'monitor', `💻 $ ${parsed.command}`);
                }
            }
            else if (parsed.type === 'upload') {
                const filePath = path.join(sess.cwd, parsed.filename);
                try {
                    const buffer = Buffer.from(parsed.binaryData, 'base64');
                    fs.writeFileSync(filePath, buffer);
                    broadcastToSession(sess, 'monitor', `📁 আপলোড: ${parsed.filename} (${(buffer.length/1024).toFixed(2)} KB)`);
                    broadcastToSession(sess, 'file_list', getFileList(sess.cwd));
                } catch(err) {
                    broadcastToSession(sess, 'error', `সেভ ব্যর্থ: ${err.message}`);
                }
            }
            else if (parsed.type === 'delete_file') {
                const filePath = path.join(sess.cwd, parsed.filename);
                try {
                    if (fs.existsSync(filePath)) {
                        fs.unlinkSync(filePath);
                        broadcastToSession(sess, 'monitor', `🗑️ ডিলিট: ${parsed.filename}`);
                        broadcastToSession(sess, 'file_list', getFileList(sess.cwd));
                    }
                } catch(err) {
                    broadcastToSession(sess, 'error', `ডিলিট ব্যর্থ: ${err.message}`);
                }
            }
            else if (parsed.type === 'list_files') {
                broadcastToSession(sess, 'file_list', getFileList(sess.cwd));
            }
            else if (parsed.type === 'run_file') {
                const filename = parsed.filename;
                const ext = filename.split('.').pop().toLowerCase();
                let command = '';
                if (ext === 'py') command = `python "${filename}"`;
                else if (ext === 'js') command = `node "${filename}"`;
                else if (ext === 'sh') command = `bash "${filename}"`;
                else command = `cat "${filename}"`;
                
                if (sess.process && sess.process.stdin) {
                    sess.process.stdin.write(command + '\n');
                    broadcastToSession(sess, 'monitor', `🚀 রান: ${command}`);
                }
            }
            else if (parsed.type === 'stop_process') {
                if (sess.process) {
                    broadcastToSession(sess, 'monitor', `⏹️ প্রসেস বন্ধ করা হচ্ছে...`);
                    sess.process.kill('SIGTERM');
                    sess.process = null;
                    broadcastToSession(sess, 'monitor', `✅ প্রসেস বন্ধ হয়েছে`);
                }
            }
            else if (parsed.type === 'restart_process') {
                if (sess.process) {
                    sess.process.kill('SIGTERM');
                    sess.process = null;
                }
                const newShell = spawn('sh', [], {
                    cwd: sess.cwd,
                    env: { ...process.env, PS1: `${sess.username}@${sess.serverName}:~$ `, TERM: 'xterm-256color' }
                });
                sess.process = newShell;
                newShell.stdout.on('data', (d) => broadcastToSession(sess, 'output', d.toString()));
                newShell.stderr.on('data', (d) => broadcastToSession(sess, 'error', d.toString()));
                broadcastToSession(sess, 'monitor', `🔄 প্রসেস রিস্টার্ট করা হয়েছে`);
            }
        } catch(e) {
            if (sess.process && sess.process.stdin) {
                sess.process.stdin.write(msgStr + '\n');
            }
        }
    }
    
    ws.on('message', (msg) => handleMessage(msg, session, ws));
    ws.on('close', () => {
        session.wsClients = session.wsClients.filter(c => c !== ws);
    });
    
    ws.send(JSON.stringify({ type: 'file_list', data: getFileList(serverDir), cwd: serverDir }));
    ws.send(JSON.stringify({ type: 'monitor', data: `🟢 টার্মিনাল ${serverName} চালু হয়েছে` }));
});

app.use(express.static(__dirname));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

const PORT = 3000;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`\n✨ টার্মিনাল হাব চালু!`);
    console.log(`📱 http://localhost:${PORT}`);
    console.log(`📁 ফাইল: ${BASE_DIR}`);
    console.log(`🔄 ৪টি টার্মিনাল একসাথে চলতে পারবে\n`);
});